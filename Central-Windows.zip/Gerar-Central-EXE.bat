@echo off
title Gerar Central.exe

cd /d "%~dp0"

echo ========================================
echo       GERADOR DA CENTRAL.EXE
echo ========================================
echo.
echo Verificando Python...

where python >nul 2>&1
if not errorlevel 1 goto PYTHON_OK

where py >nul 2>&1
if not errorlevel 1 goto PY_LAUNCHER

echo.
echo ERRO: Python nao encontrado.
echo Execute primeiro o Instalar-Central.bat
echo.
pause
exit /b 1

:PYTHON_OK
set "PYTHON=python"
goto BUILD

:PY_LAUNCHER
set "PYTHON=py"

:BUILD
echo.
echo Instalando PyInstaller...
%PYTHON% -m pip install pyinstaller

if errorlevel 1 (
    echo.
    echo ERRO ao instalar o PyInstaller.
    pause
    exit /b 1
)

echo.
echo Gerando Central.exe...
echo.

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist

%PYTHON% -m PyInstaller --onefile --clean --noconfirm --name Central servidor.py

if errorlevel 1 (
    echo.
    echo ERRO ao gerar o executavel.
    pause
    exit /b 1
)

echo.
echo Copiando arquivos necessarios para o pacote final...
copy /Y central-investimentos.html dist\central-investimentos.html >nul
copy /Y brapi0token.txt dist\brapi0token.txt >nul

echo.
echo ========================================
echo       CENTRAL.EXE GERADO COM SUCESSO
echo ========================================
echo.
echo Pacote final:
echo dist\
echo.
echo Conteudo:
echo Central.exe
echo central-investimentos.html
echo brapi0token.txt
echo.
echo Essa pasta dist pode ser copiada para outro PC Windows.
echo.
pause
